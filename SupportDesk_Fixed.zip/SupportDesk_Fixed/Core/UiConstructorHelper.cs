using System;
using System.Drawing;
using System.Windows.Forms;

namespace SupportDesk.Core
{
    /// <summary>
    /// Чистый конструктор видимости кнопок и виджетов.
    /// Заменяет хаотичные if-else в MnBtnMenuConstructor.
    /// Использует FlowLayoutPanel — кнопки сами выстраиваются.
    /// </summary>
    public static class UiConstructorHelper
    {
        /// <summary>
        /// Настраивает видимость и порядок мини-кнопок меню.
        /// Передайте кнопки в желаемом порядке.
        /// </summary>
        public static void ApplyMiniMenuButtons(
            FlowLayoutPanel container,
            params (Control button, bool visible)[] buttons)
        {
            if (container == null) return;

            container.Controls.Clear();
            container.FlowDirection = FlowDirection.LeftToRight;
            container.WrapContents = false;
            container.AutoSize = true;
            container.Padding = new Padding(4);

            foreach (var (button, visible) in buttons)
            {
                if (button == null) continue;
                button.Visible = visible;
                if (visible)
                {
                    button.Margin = new Padding(6, 0, 6, 0);
                    container.Controls.Add(button);
                }
            }
        }

        /// <summary>
        /// Настраивает основные кнопки бокового меню.
        /// </summary>
        public static void ApplySideMenuButtons(
            FlowLayoutPanel container,
            params (Control button, bool visible)[] buttons)
        {
            if (container == null) return;

            container.Controls.Clear();
            container.FlowDirection = FlowDirection.TopDown;
            container.WrapContents = false;
            container.AutoSize = true;

            foreach (var (button, visible) in buttons)
            {
                if (button == null) continue;
                button.Visible = visible;
                if (visible)
                {
                    button.Margin = new Padding(0, 4, 0, 4);
                    button.Width = container.ClientSize.Width - 8;
                    container.Controls.Add(button);
                }
            }
        }

        /// <summary>
        /// Настраивает виджеты (календарь, пользователи, инвентарь).
        /// </summary>
        public static void ApplyWidgets(
            Control calendar,
            Control usersPanel,
            Control inventoryPanel,
            bool showCalendar,
            bool showUsers,
            bool showInventory)
        {
            if (calendar != null) calendar.Visible = showCalendar;
            if (usersPanel != null) usersPanel.Visible = showUsers;
            if (inventoryPanel != null) inventoryPanel.Visible = showInventory;
        }

        /// <summary>
        /// Корректирует размер и позицию основной GroupBox в зависимости от виджетов.
        /// </summary>
        public static void AdjustMainGroupBox(
            Control groupBox,
            int windowHeight,
            bool anyWidgetVisible)
        {
            if (groupBox == null) return;

            if (windowHeight <= 500)
            {
                groupBox.Size = new Size(982, ConstructorWindow.sizeGroupBoxUser);
                groupBox.Location = new Point(210, ConstructorWindow.locationGroupBoxOffWidgets);
            }
            else if (anyWidgetVisible)
            {
                groupBox.Size = new Size(982, ConstructorWindow.sizeGroupBoxOnWidgets);
                groupBox.Location = new Point(210, ConstructorWindow.locationGroupBoxOnWidgets);
            }
            else
            {
                groupBox.Size = new Size(982, ConstructorWindow.sizeGroupBoxOffWidgets);
                groupBox.Location = new Point(210, ConstructorWindow.locationGroupBoxOffWidgets);
            }
        }

        /// <summary>
        /// Создаёт индикатор загрузки (overlay).
        /// </summary>
        public static Panel CreateBusyOverlay(Control parent, string text = "Загрузка...")
        {
            var overlay = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(180, 255, 255, 255),
                Visible = false
            };

            var lbl = new Label
            {
                Text = text,
                Font = new Font("Segoe UI Semibold", 14f),
                ForeColor = Color.FromArgb(30, 41, 59),
                AutoSize = true
            };

            overlay.Controls.Add(lbl);
            parent.Controls.Add(overlay);
            overlay.BringToFront();

            // Центрируем текст
            overlay.Resize += (s, e) =>
            {
                lbl.Location = new Point(
                    (overlay.Width - lbl.Width) / 2,
                    (overlay.Height - lbl.Height) / 2);
            };

            return overlay;
        }

        public static void ShowBusy(Panel overlay, bool show)
        {
            if (overlay == null) return;
            overlay.Visible = show;
            if (show) overlay.BringToFront();
        }
    }
}
