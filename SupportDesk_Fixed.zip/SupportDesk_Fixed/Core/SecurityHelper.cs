using System;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace SupportDesk.Core
{
    /// <summary>
    /// Безопасные утилиты: хеширование паролей, валидация, защита от инъекций.
    /// </summary>
    public static class SecurityHelper
    {
        // Простое, но лучше чем plain-text. В продакшене — BCrypt/Argon2.
        private const int SaltSize = 16;
        private const int HashSize = 32;
        private const int Iterations = 100_000;

        public static string HashPassword(string password)
        {
            if (string.IsNullOrEmpty(password))
                throw new ArgumentException("Пароль не может быть пустым");

            byte[] salt = new byte[SaltSize];
            using (var rng = RandomNumberGenerator.Create())
                rng.GetBytes(salt);

            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, Iterations, HashAlgorithmName.SHA256))
            {
                byte[] hash = pbkdf2.GetBytes(HashSize);
                byte[] hashBytes = new byte[SaltSize + HashSize];
                Array.Copy(salt, 0, hashBytes, 0, SaltSize);
                Array.Copy(hash, 0, hashBytes, SaltSize, HashSize);
                return Convert.ToBase64String(hashBytes);
            }
        }

        public static bool VerifyPassword(string password, string storedHash)
        {
            if (string.IsNullOrEmpty(password) || string.IsNullOrEmpty(storedHash))
                return false;

            try
            {
                byte[] hashBytes = Convert.FromBase64String(storedHash);
                if (hashBytes.Length != SaltSize + HashSize)
                    return false;

                byte[] salt = new byte[SaltSize];
                Array.Copy(hashBytes, 0, salt, 0, SaltSize);

                using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, Iterations, HashAlgorithmName.SHA256))
                {
                    byte[] hash = pbkdf2.GetBytes(HashSize);
                    for (int i = 0; i < HashSize; i++)
                        if (hashBytes[i + SaltSize] != hash[i])
                            return false;
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Очистка ввода от опасных символов (дополнительная защита).
        /// </summary>
        public static string SanitizeInput(string input)
        {
            if (string.IsNullOrEmpty(input)) return string.Empty;
            return Regex.Replace(input.Trim(), @"[^\w\s@.\-а-яА-ЯёЁ]", "");
        }

        public static bool IsWeakPassword(string password)
        {
            if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
                return true;

            string lower = password.ToLowerInvariant();
            foreach (string bad in CertificateSecurity.noPasswords)
            {
                if (lower.Contains(bad.ToLowerInvariant()))
                    return true;
            }
            return false;
        }
    }
}
