using System;
using System.Data;
using System.Data.SQLite;
using System.Threading.Tasks;

namespace SupportDesk.Core
{
    /// <summary>
    /// Единая точка работы с SQLite. Все запросы — только параметризованные.
    /// </summary>
    public static class DbHelper
    {
        public static SQLiteConnection CreateConnection()
        {
            var conn = new SQLiteConnection(Database.connectionString);
            conn.Open();
            return conn;
        }

        public static async Task<SQLiteConnection> CreateConnectionAsync()
        {
            var conn = new SQLiteConnection(Database.connectionString);
            await conn.OpenAsync();
            return conn;
        }

        public static async Task<DataTable> ExecuteQueryAsync(string sql, params SQLiteParameter[] parameters)
        {
            using (var conn = await CreateConnectionAsync())
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                var adapter = new SQLiteDataAdapter(cmd);
                var table = new DataTable();
                adapter.Fill(table);
                return table;
            }
        }

        public static async Task<int> ExecuteNonQueryAsync(string sql, params SQLiteParameter[] parameters)
        {
            using (var conn = await CreateConnectionAsync())
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                return await cmd.ExecuteNonQueryAsync();
            }
        }

        public static async Task<object> ExecuteScalarAsync(string sql, params SQLiteParameter[] parameters)
        {
            using (var conn = await CreateConnectionAsync())
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                return await cmd.ExecuteScalarAsync();
            }
        }
    }
}
