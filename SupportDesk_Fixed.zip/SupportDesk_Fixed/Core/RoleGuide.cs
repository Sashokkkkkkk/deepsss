using System.Collections.Generic;

namespace SupportDesk.Core
{
    /// <summary>
    /// Централизованное описание ролей и прав.
    /// </summary>
    public static class RoleGuide
    {
        public enum Role
        {
            ADMIN,
            WORKER,
            USER
        }

        public class RoleInfo
        {
            public string Code { get; set; }
            public string DisplayName { get; set; }
            public string Description { get; set; }
            public List<string> Permissions { get; set; }
            public List<string> Restrictions { get; set; }
        }

        public static readonly Dictionary<string, RoleInfo> Roles = new Dictionary<string, RoleInfo>
        {
            ["ADMIN"] = new RoleInfo
            {
                Code = "ADMIN",
                DisplayName = "Администратор",
                Description = "Полный контроль над системой Support Desk. Управление пользователями, правами, справочниками и аналитикой.",
                Permissions = new List<string>
                {
                    "Создание / редактирование / блокировка пользователей",
                    "Назначение ролей и детальных прав (RightsRoles)",
                    "Просмотр и управление всеми заявками",
                    "Все справочники (кабинеты, типы работ, статусы, исполнители)",
                    "Картриджи, лицензии, инвентарь, пароли, контакты",
                    "Формирование Excel-отчётов",
                    "Доступ к модулю «Аналитика и SLA»",
                    "Настройки системы и Telegram-бота",
                    "Просмотр логов"
                },
                Restrictions = new List<string>
                {
                    "Нет ограничений"
                }
            },
            ["WORKER"] = new RoleInfo
            {
                Code = "WORKER",
                DisplayName = "Исполнитель (техподдержка)",
                Description = "Работает с назначенными заявками, ведёт учёт расходников и оборудования.",
                Permissions = new List<string>
                {
                    "Просмотр заявок, где он указан как исполнитель или дублёр",
                    "Принятие заявки («Новая» → «В работе»)",
                    "Закрытие заявки с результатом",
                    "Картриджи, лицензии, инвентарь",
                    "Пароли и внешние контакты",
                    "Календарь задач",
                    "Личный кабинет"
                },
                Restrictions = new List<string>
                {
                    "Нельзя управлять пользователями и правами",
                    "Нельзя создавать заявки от имени других",
                    "Нет доступа к модулю аналитики SLA",
                    "Нет доступа к настройкам системы"
                }
            },
            ["USER"] = new RoleInfo
            {
                Code = "USER",
                DisplayName = "Пользователь",
                Description = "Обычный сотрудник. Создаёт заявки и отслеживает их статус.",
                Permissions = new List<string>
                {
                    "Создание новой заявки",
                    "Просмотр своих заявок",
                    "Прикрепление файлов к заявке",
                    "Личный кабинет (смена пароля, аватара)",
                    "Получение уведомлений"
                },
                Restrictions = new List<string>
                {
                    "Нет доступа к чужим заявкам",
                    "Нет доступа к справочникам и отчётам",
                    "Нет доступа к картриджам / лицензиям / инвентарю",
                    "Нет доступа к аналитике"
                }
            }
        };

        public static string GetPrettyGuide()
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("══════════════════════════════════════════════════════════════");
            sb.AppendLine("           РУКОВОДСТВО ПО РОЛЯМ SUPPORT DESK");
            sb.AppendLine("══════════════════════════════════════════════════════════════");
            sb.AppendLine();

            foreach (var role in Roles.Values)
            {
                sb.AppendLine($"▶ {role.DisplayName.ToUpper()} ({role.Code})");
                sb.AppendLine($"  {role.Description}");
                sb.AppendLine();
                sb.AppendLine("  Разрешено:");
                foreach (var p in role.Permissions)
                    sb.AppendLine($"    ✓ {p}");
                sb.AppendLine();
                sb.AppendLine("  Запрещено:");
                foreach (var r in role.Restrictions)
                    sb.AppendLine($"    ✗ {r}");
                sb.AppendLine();
                sb.AppendLine("──────────────────────────────────────────────────────────────");
            }

            sb.AppendLine();
            sb.AppendLine("Как назначаются права:");
            sb.AppendLine("  1. При логине загружается запись из таблицы RightsRoles по groupUser.");
            sb.AppendLine("  2. Флаги записываются в ConstructorWindow и MiniButtonMenuConfig.");
            sb.AppendLine("  3. Видимость кнопок и виджетов полностью зависит от этих флагов.");
            sb.AppendLine();
            sb.AppendLine("Рекомендация: для новых ролей добавляйте запись в RightsRoles");
            sb.AppendLine("и Functional, не хардкодьте проверки в коде форм.");

            return sb.ToString();
        }
    }
}
