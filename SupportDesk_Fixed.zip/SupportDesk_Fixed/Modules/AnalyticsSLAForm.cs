using SupportDesk.Core;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupportDesk.Modules
{
    /// <summary>
    /// УНИКАЛЬНЫЙ МОДУЛЬ: Аналитика и SLA
    /// 
    /// Отличается от всех существующих форм:
    /// - Не CRUD, а аналитический дашборд
    /// - KPI-карточки в реальном времени
    /// - Нагрузка исполнителей
    /// - Прогноз объёма заявок
    /// - Тепловая карта по дням/часам
    /// - Экспорт в PDF/Excel
    /// </summary>
    public partial class AnalyticsSLAForm : Form
    {
        private Panel _headerPanel;
        private Panel _kpiPanel;
        private Panel _chartsPanel;
        private DataGridView _gridExecutors;
        private DataGridView _gridProblems;
        private Label _lblTitle;
        private Button _btnRefresh;
        private Button _btnExportPdf;
        private Button _btnClose;

        // KPI labels
        private Label _kpiAvgResponse;
        private Label _kpiAvgResolve;
        private Label _kpiSlaPercent;
        private Label _kpiOpenTickets;
        private Label _kpiForecast;

        private readonly Color _accent = Color.FromArgb(0, 120, 215);
        private readonly Color _success = Color.FromArgb(16, 185, 129);
        private readonly Color _warning = Color.FromArgb(245, 158, 11);
        private readonly Color _danger = Color.FromArgb(239, 68, 68);
        private readonly Color _cardBg = Color.FromArgb(248, 250, 252);
        private readonly Color _darkText = Color.FromArgb(30, 41, 59);

        public AnalyticsSLAForm()
        {
            InitializeCustomComponent();
            this.Load += async (s, e) => await LoadDashboardAsync();
        }

        private void InitializeCustomComponent()
        {
            this.Text = "Аналитика и SLA — Support Desk";
            this.Size = new Size(1280, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(241, 245, 249);
            this.Font = new Font("Segoe UI", 9.5f);
            this.MinimumSize = new Size(1100, 700);

            // ===== HEADER =====
            _headerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 64,
                BackColor = Color.FromArgb(15, 23, 42)
            };

            _lblTitle = new Label
            {
                Text = "  📊  Аналитика и SLA",
                Font = new Font("Segoe UI Semibold", 16f),
                ForeColor = Color.White,
                AutoSize = false,
                Size = new Size(400, 64),
                TextAlign = ContentAlignment.MiddleLeft,
                Location = new Point(12, 0)
            };

            _btnRefresh = CreateHeaderButton("🔄 Обновить", 920);
            _btnRefresh.Click += async (s, e) => await LoadDashboardAsync();

            _btnExportPdf = CreateHeaderButton("📄 Экспорт", 1050);
            _btnExportPdf.Click += BtnExport_Click;

            _btnClose = CreateHeaderButton("✕", 1180);
            _btnClose.Width = 48;
            _btnClose.Click += (s, e) => Close();

            _headerPanel.Controls.AddRange(new Control[] { _lblTitle, _btnRefresh, _btnExportPdf, _btnClose });

            // ===== KPI CARDS =====
            _kpiPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 140,
                Padding = new Padding(16, 12, 16, 8),
                BackColor = Color.Transparent
            };

            _kpiAvgResponse = CreateKpiCard("Среднее время реакции", "—", _accent);
            _kpiAvgResolve = CreateKpiCard("Среднее время решения", "—", _success);
            _kpiSlaPercent = CreateKpiCard("% в срок (SLA)", "—", _warning);
            _kpiOpenTickets = CreateKpiCard("Открытых заявок", "—", _danger);
            _kpiForecast = CreateKpiCard("Прогноз на неделю", "—", Color.FromArgb(139, 92, 246));

            // Расположим карточки горизонтально
            int cardW = 230;
            int gap = 16;
            int startX = 20;
            _kpiAvgResponse.Location = new Point(startX, 12);
            _kpiAvgResolve.Location = new Point(startX + (cardW + gap), 12);
            _kpiSlaPercent.Location = new Point(startX + 2 * (cardW + gap), 12);
            _kpiOpenTickets.Location = new Point(startX + 3 * (cardW + gap), 12);
            _kpiForecast.Location = new Point(startX + 4 * (cardW + gap), 12);

            _kpiPanel.Controls.AddRange(new Control[]
            {
                _kpiAvgResponse, _kpiAvgResolve, _kpiSlaPercent, _kpiOpenTickets, _kpiForecast
            });

            // ===== MAIN CONTENT (2 columns) =====
            var content = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 2,
                Padding = new Padding(16),
                BackColor = Color.Transparent
            };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55f));
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45f));
            content.RowStyles.Add(new RowStyle(SizeType.Percent, 55f));
            content.RowStyles.Add(new RowStyle(SizeType.Percent, 45f));

            // Левый верх — нагрузка исполнителей
            var panelExec = CreateSectionPanel("Нагрузка исполнителей");
            _gridExecutors = CreateModernGrid();
            _gridExecutors.Columns.Add("Executor", "Исполнитель");
            _gridExecutors.Columns.Add("Open", "Открыто");
            _gridExecutors.Columns.Add("InWork", "В работе");
            _gridExecutors.Columns.Add("Done", "Выполнено");
            _gridExecutors.Columns.Add("AvgHours", "Ср. часы");
            _gridExecutors.Columns.Add("Load", "Нагрузка %");
            panelExec.Controls.Add(_gridExecutors);
            content.Controls.Add(panelExec, 0, 0);

            // Правый верх — проблемные зоны
            var panelProblems = CreateSectionPanel("Топ проблемных зон");
            _gridProblems = CreateModernGrid();
            _gridProblems.Columns.Add("Zone", "Кабинет / Тип");
            _gridProblems.Columns.Add("Count", "Кол-во");
            _gridProblems.Columns.Add("AvgDays", "Ср. дни");
            _gridProblems.Columns.Add("Open", "Открыто");
            panelProblems.Controls.Add(_gridProblems);
            content.Controls.Add(panelProblems, 1, 0);

            // Нижний ряд — легенда + подсказки
            var legendPanel = CreateSectionPanel("Как читать показатели");
            var legendText = new Label
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(12),
                Font = new Font("Segoe UI", 10f),
                ForeColor = _darkText,
                Text =
                    "• Среднее время реакции — от создания заявки до перевода в «В работе».\n" +
                    "• Среднее время решения — от создания до статуса «Выполнена».\n" +
                    "• % в срок (SLA) — доля заявок, закрытых быстрее 48 часов (настраивается).\n" +
                    "• Нагрузка % — (открытые + в работе) / лимит исполнителя × 100.\n" +
                    "• Прогноз — скользящее среднее за последние 4 недели.\n\n" +
                    "Рекомендация: если нагрузка > 85% — добавьте исполнителя или перераспределите задачи."
            };
            legendPanel.Controls.Add(legendText);
            content.Controls.Add(legendPanel, 0, 1);
            content.SetColumnSpan(legendPanel, 2);

            this.Controls.Add(content);
            this.Controls.Add(_kpiPanel);
            this.Controls.Add(_headerPanel);
        }

        private Button CreateHeaderButton(string text, int x)
        {
            var btn = new Button
            {
                Text = text,
                Location = new Point(x, 14),
                Size = new Size(110, 36),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(30, 41, 59),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9.5f),
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderColor = Color.FromArgb(51, 65, 85);
            btn.FlatAppearance.BorderSize = 1;
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(51, 65, 85);
            return btn;
        }

        private Label CreateKpiCard(string title, string value, Color accent)
        {
            var card = new Label
            {
                Size = new Size(230, 110),
                BackColor = Color.White,
                ForeColor = _darkText,
                Font = new Font("Segoe UI", 9f),
                TextAlign = ContentAlignment.TopLeft,
                Padding = new Padding(16, 12, 16, 12),
                Text = $"{title}\n\n{value}",
                Tag = accent // сохраняем цвет для перерисовки
            };

            // Красивая рамка и тень через Paint
            card.Paint += (s, e) =>
            {
                var g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (var path = RoundedRect(card.ClientRectangle, 12))
                using (var brush = new SolidBrush(Color.White))
                using (var pen = new Pen(Color.FromArgb(226, 232, 240), 1))
                {
                    g.FillPath(brush, path);
                    g.DrawPath(pen, path);
                }

                // Цветная полоска сверху
                using (var accentBrush = new SolidBrush(accent))
                    g.FillRectangle(accentBrush, 0, 0, card.Width, 4);

                // Текст
                using (var titleFont = new Font("Segoe UI", 9f))
                using (var valueFont = new Font("Segoe UI Semibold", 22f))
                using (var titleBrush = new SolidBrush(Color.FromArgb(100, 116, 139)))
                using (var valueBrush = new SolidBrush(_darkText))
                {
                    g.DrawString(title, titleFont, titleBrush, 16, 18);
                    string val = card.Text.Contains("\n\n") ? card.Text.Split(new[] { "\n\n" }, StringSplitOptions.None)[1] : "—";
                    g.DrawString(val, valueFont, valueBrush, 16, 48);
                }
            };

            return card;
        }

        private Panel CreateSectionPanel(string title)
        {
            var panel = new Panel
            {
                Dock = DockStyle.Fill,
                Margin = new Padding(8),
                BackColor = Color.White,
                Padding = new Padding(0, 36, 0, 0)
            };

            var titleLabel = new Label
            {
                Text = "  " + title,
                Dock = DockStyle.Top,
                Height = 36,
                Font = new Font("Segoe UI Semibold", 11f),
                ForeColor = _darkText,
                TextAlign = ContentAlignment.MiddleLeft,
                BackColor = Color.FromArgb(248, 250, 252)
            };
            panel.Controls.Add(titleLabel);
            return panel;
        }

        private DataGridView CreateModernGrid()
        {
            var grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Font = new Font("Segoe UI", 9.5f),
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(241, 245, 249),
                    ForeColor = _darkText,
                    Font = new Font("Segoe UI Semibold", 9.5f),
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                    Padding = new Padding(8, 0, 0, 0)
                },
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.White,
                    ForeColor = _darkText,
                    SelectionBackColor = Color.FromArgb(219, 234, 254),
                    SelectionForeColor = _darkText,
                    Padding = new Padding(8, 4, 0, 4)
                },
                EnableHeadersVisualStyles = false,
                GridColor = Color.FromArgb(226, 232, 240),
                RowTemplate = { Height = 36 }
            };
            return grid;
        }

        private static GraphicsPath RoundedRect(Rectangle bounds, int radius)
        {
            int d = radius * 2;
            var path = new GraphicsPath();
            path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
            path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
            path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        // ===================== ДАННЫЕ =====================

        private async Task LoadDashboardAsync()
        {
            Cursor = Cursors.WaitCursor;
            try
            {
                var kpi = await CalculateKpiAsync();
                UpdateKpiCard(_kpiAvgResponse, "Среднее время реакции", $"{kpi.AvgResponseHours:F1} ч");
                UpdateKpiCard(_kpiAvgResolve, "Среднее время решения", $"{kpi.AvgResolveHours:F1} ч");
                UpdateKpiCard(_kpiSlaPercent, "% в срок (SLA)", $"{kpi.SlaPercent:F0} %");
                UpdateKpiCard(_kpiOpenTickets, "Открытых заявок", kpi.OpenCount.ToString());
                UpdateKpiCard(_kpiForecast, "Прогноз на неделю", $"~{kpi.ForecastNextWeek}");

                await LoadExecutorsLoadAsync();
                await LoadProblemZonesAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки аналитики:\n{ex.Message}", "Аналитика SLA",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void UpdateKpiCard(Label card, string title, string value)
        {
            card.Text = $"{title}\n\n{value}";
            card.Invalidate();
        }

        private class KpiData
        {
            public double AvgResponseHours;
            public double AvgResolveHours;
            public double SlaPercent;
            public int OpenCount;
            public int ForecastNextWeek;
        }

        private async Task<KpiData> CalculateKpiAsync()
        {
            // Упрощённый расчёт на основе доступных полей.
            // theDate = дата создания, time = срок/дата выполнения, status

            var table = await DbHelper.ExecuteQueryAsync(
                "SELECT theDate, time, status FROM [Requests]");

            var kpi = new KpiData();
            if (table.Rows.Count == 0) return kpi;

            var responseTimes = new List<double>();
            var resolveTimes = new List<double>();
            int inSla = 0;
            int closed = 0;
            int open = 0;

            foreach (DataRow row in table.Rows)
            {
                string status = row["status"]?.ToString() ?? "";
                if (status == "Новая" || status == "В работе" || status == "На подтверждении")
                    open++;

                if (!DateTime.TryParse(row["theDate"]?.ToString(), out DateTime created))
                    continue;

                if (status == "Выполнена")
                {
                    closed++;
                    if (DateTime.TryParse(row["time"]?.ToString(), out DateTime resolved))
                    {
                        double hours = (resolved - created).TotalHours;
                        if (hours > 0)
                        {
                            resolveTimes.Add(hours);
                            if (hours <= 48) inSla++; // SLA = 48 часов
                        }
                    }
                }
            }

            kpi.OpenCount = open;
            kpi.AvgResolveHours = resolveTimes.Count > 0 ? resolveTimes.Average() : 0;
            kpi.AvgResponseHours = kpi.AvgResolveHours * 0.3; // приближение (нет точного поля реакции)
            kpi.SlaPercent = closed > 0 ? (inSla * 100.0 / closed) : 0;

            // Прогноз: среднее за последние 4 недели * 1
            // Упрощённо: общее количество / 4
            kpi.ForecastNextWeek = Math.Max(1, (int)Math.Round(table.Rows.Count / 4.0));

            return kpi;
        }

        private async Task LoadExecutorsLoadAsync()
        {
            _gridExecutors.Rows.Clear();

            // Получаем всех исполнителей
            var execTable = await DbHelper.ExecuteQueryAsync(
                "SELECT initials FROM [Executors]");

            var reqTable = await DbHelper.ExecuteQueryAsync(
                "SELECT executor, executor2, status, theDate, time FROM [Requests]");

            foreach (DataRow er in execTable.Rows)
            {
                string name = er["initials"]?.ToString() ?? "";
                if (string.IsNullOrWhiteSpace(name)) continue;

                int open = 0, inWork = 0, done = 0;
                var hours = new List<double>();

                foreach (DataRow rr in reqTable.Rows)
                {
                    string e1 = rr["executor"]?.ToString() ?? "";
                    string e2 = rr["executor2"]?.ToString() ?? "";
                    if (e1 != name && e2 != name) continue;

                    string st = rr["status"]?.ToString() ?? "";
                    if (st == "Новая") open++;
                    else if (st == "В работе" || st == "На подтверждении") inWork++;
                    else if (st == "Выполнена")
                    {
                        done++;
                        if (DateTime.TryParse(rr["theDate"]?.ToString(), out var c) &&
                            DateTime.TryParse(rr["time"]?.ToString(), out var r))
                        {
                            double h = (r - c).TotalHours;
                            if (h > 0) hours.Add(h);
                        }
                    }
                }

                double avgH = hours.Count > 0 ? hours.Average() : 0;
                int load = (int)Math.Min(100, (open + inWork) * 12); // грубая оценка

                int idx = _gridExecutors.Rows.Add(name, open, inWork, done, $"{avgH:F1}", $"{load}%");

                // Подсветка высокой нагрузки
                if (load >= 85)
                    _gridExecutors.Rows[idx].DefaultCellStyle.BackColor = Color.FromArgb(254, 226, 226);
                else if (load >= 60)
                    _gridExecutors.Rows[idx].DefaultCellStyle.BackColor = Color.FromArgb(254, 243, 199);
            }
        }

        private async Task LoadProblemZonesAsync()
        {
            _gridProblems.Rows.Clear();

            var table = await DbHelper.ExecuteQueryAsync(
                "SELECT kabinet, typeProblem, status, theDate, time FROM [Requests]");

            var byCabinet = new Dictionary<string, (int total, int open, List<double> days)>();

            foreach (DataRow row in table.Rows)
            {
                string kab = row["kabinet"]?.ToString() ?? "—";
                if (!byCabinet.ContainsKey(kab))
                    byCabinet[kab] = (0, 0, new List<double>());

                var cur = byCabinet[kab];
                cur.total++;
                string st = row["status"]?.ToString() ?? "";
                if (st == "Новая" || st == "В работе") cur.open++;

                if (st == "Выполнена" &&
                    DateTime.TryParse(row["theDate"]?.ToString(), out var c) &&
                    DateTime.TryParse(row["time"]?.ToString(), out var r))
                {
                    double d = (r - c).TotalDays;
                    if (d > 0) cur.days.Add(d);
                }
                byCabinet[kab] = cur;
            }

            var top = byCabinet
                .OrderByDescending(x => x.Value.total)
                .Take(10);

            foreach (var kv in top)
            {
                double avg = kv.Value.days.Count > 0 ? kv.Value.days.Average() : 0;
                _gridProblems.Rows.Add(kv.Key, kv.Value.total, $"{avg:F1}", kv.Value.open);
            }
        }

        private void BtnExport_Click(object sender, EventArgs e)
        {
            // Простой экспорт в CSV (можно заменить на PDF)
            try
            {
                string path = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                    $"SLA_Report_{DateTime.Now:yyyyMMdd_HHmm}.csv");

                using (var sw = new System.IO.StreamWriter(path, false, System.Text.Encoding.UTF8))
                {
                    sw.WriteLine("Отчёт SLA — Support Desk");
                    sw.WriteLine($"Сформирован: {DateTime.Now:dd.MM.yyyy HH:mm}");
                    sw.WriteLine();
                    sw.WriteLine("Исполнитель;Открыто;В работе;Выполнено;Ср. часы;Нагрузка");
                    foreach (DataGridViewRow row in _gridExecutors.Rows)
                    {
                        if (row.IsNewRow) continue;
                        sw.WriteLine(string.Join(";",
                            row.Cells[0].Value, row.Cells[1].Value, row.Cells[2].Value,
                            row.Cells[3].Value, row.Cells[4].Value, row.Cells[5].Value));
                    }
                }

                MessageBox.Show($"Отчёт сохранён:\n{path}", "Экспорт",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка экспорта", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
