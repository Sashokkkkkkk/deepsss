using SupportDesk.Core;
using SupportDesk.forms;
using System;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupportDesk
{
    /// <summary>
    /// Исправленная форма входа.
    /// - Полностью параметризованные запросы (защита от SQL-инъекций)
    /// - Корректная логика блокировки
    /// - Безопасное «Запомнить меня» (только логин)
    /// - Правильное закрытие ресурсов
    /// </summary>
    public partial class LoginForm : Form
    {
        #region Настройки формы (перетаскивание)
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        #endregion

        private SQLiteConnection _db;
        private readonly DateTime _thisDay = DateTime.Now;
        private readonly string _tempPath = Path.GetTempPath();
        private readonly string _rememberDir = RememberLogin.directoryName;
        private readonly string _rememberFile = RememberLogin.fileName;
        private int _attemptLogin = 3;

        public LoginForm()
        {
            InitializeComponent();
            LoadRememberedLogin();
        }

        private async void LoginForm_Load(object sender, EventArgs e)
        {
            RootAccess.CheckRunApp = true;
            _db = await DbHelper.CreateConnectionAsync();
            // TelegramForm можно показывать по флагу, а не всегда
        }

        #region Регистрация / Выход

        private void ButtonRegUser_Click(object sender, EventArgs e)
        {
            var fReg = new RegisterForm();
            fReg.FormClosed += (s, args) => Close();
            fReg.Show();
            Hide();
        }

        private void ButtonExit_Click(object sender, EventArgs e) => Close();

        private void Form_FormClosed(object sender, FormClosedEventArgs e) => Close();

        #endregion

        #region Глазик пароля

        private void ExpUIButtonIconCheckUnlock_Click(object sender, EventArgs e)
        {
            TextBoxPassword.UseSystemPasswordChar = true;
            expUIButtonIconCheckUnlock.Visible = false;
            expUIButtonIconCheckLock.Visible = true;
        }

        private void ExpUIButtonIconCheckLock_Click(object sender, EventArgs e)
        {
            TextBoxPassword.UseSystemPasswordChar = false;
            expUIButtonIconCheckUnlock.Visible = true;
            expUIButtonIconCheckLock.Visible = false;
        }

        #endregion

        #region Забыли пароль

        private void LabelForgotPassword_Click(object sender, EventArgs e)
        {
            if (DataRequests.IsOpen) return;
            // TODO: открыть ForgotPasswordForm
            DataRequests.IsOpen = true;
        }

        #endregion

        #region Запомнить меня (только логин)

        private void LoadRememberedLogin()
        {
            try
            {
                string fullPath = Path.Combine(_tempPath, _rememberDir, _rememberFile);
                if (!File.Exists(fullPath)) return;

                string content = File.ReadAllText(fullPath).Trim();
                if (string.IsNullOrEmpty(content)) return;

                // Новый формат: только логин (безопаснее)
                // Старый формат login:password — берём только логин
                string[] parts = content.Split(':');
                TextBoxLogin.Text = parts[0];
            }
            catch
            {
                // игнорируем ошибки чтения
            }
        }

        private void CheckRemember_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                string dir = Path.Combine(_tempPath, _rememberDir);
                Directory.CreateDirectory(dir);
                string fullPath = Path.Combine(dir, _rememberFile);

                if (CheckRemember.Checked && !string.IsNullOrWhiteSpace(TextBoxLogin.Text))
                {
                    // Сохраняем ТОЛЬКО логин
                    File.WriteAllText(fullPath, TextBoxLogin.Text.Trim());
                }
                else if (!CheckRemember.Checked && File.Exists(fullPath))
                {
                    File.Delete(fullPath);
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"Не удалось сохранить настройки: {ex.Message}", "Ошибка", "Error");
            }
        }

        #endregion

        #region Управление формой

        private void FormControl(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        #endregion

        #region Валидация ввода

        private void TextBoxPassword_TextChanged(object sender, EventArgs e)
        {
            // Разрешаем буквы, цифры и базовые спецсимволы
            string cleaned = Regex.Replace(TextBoxPassword.Text, @"[^A-Za-z0-9!@#$%^&*()_+\-=]", "");
            if (cleaned != TextBoxPassword.Text)
            {
                int pos = TextBoxPassword.SelectionStart;
                TextBoxPassword.Text = cleaned;
                TextBoxPassword.SelectionStart = Math.Min(pos, cleaned.Length);
            }
            UpdateEnterButtonState();
        }

        private void TextBoxLogin_TextChanged(object sender, EventArgs e)
        {
            string cleaned = Regex.Replace(TextBoxLogin.Text, @"[^A-Za-z0-9_\-.]", "");
            if (cleaned != TextBoxLogin.Text)
            {
                int pos = TextBoxLogin.SelectionStart;
                TextBoxLogin.Text = cleaned;
                TextBoxLogin.SelectionStart = Math.Min(pos, cleaned.Length);
            }
            UpdateEnterButtonState();
        }

        private void UpdateEnterButtonState()
        {
            ButtonEnterLogin.Enabled = !string.IsNullOrWhiteSpace(TextBoxLogin.Text)
                                    && !string.IsNullOrWhiteSpace(TextBoxPassword.Text);
        }

        #endregion

        #region Вход (главная логика)

        private async void ButtonEnterLogin_Click(object sender, EventArgs e)
        {
            string login = TextBoxLogin.Text.Trim();
            string password = TextBoxPassword.Text;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBoxUI.Show("Введите логин и пароль", "Ошибка авторизации", "Error");
                return;
            }

            ButtonEnterLogin.Enabled = false;
            Cursor = Cursors.WaitCursor;

            try
            {
                // 1. Ищем пользователя по логину (параметризованный запрос)
                const string sqlUser = @"
                    SELECT * FROM [Users] 
                    WHERE [login] = @login 
                    LIMIT 1";

                var table = await DbHelper.ExecuteQueryAsync(sqlUser,
                    new SQLiteParameter("@login", login));

                if (table.Rows.Count == 0)
                {
                    // Пользователь не найден — не уменьшаем попытки (чтобы не раскрывать существование)
                    MessageBoxUI.Show("Неверный логин или пароль", "Ошибка авторизации", "Error");
                    return;
                }

                DataRow row = table.Rows[0];
                string storedPass = row["pass"]?.ToString() ?? "";
                string typeAccess = row["typeAccess"]?.ToString() ?? "";

                // 2. Проверка блокировки
                if (string.Equals(typeAccess, "LOCKED", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBoxUI.Show(
                        "Учётная запись заблокирована! Свяжитесь с системным администратором.",
                        "Ошибка авторизации", "Error");
                    Close();
                    return;
                }

                // 3. Проверка пароля
                // Поддержка старых plain-text паролей + новых хешей
                bool passwordOk = storedPass == password
                              || SecurityHelper.VerifyPassword(password, storedPass);

                if (!passwordOk)
                {
                    _attemptLogin--;

                    if (_attemptLogin <= 0)
                    {
                        // Блокируем только существующего пользователя
                        await DbHelper.ExecuteNonQueryAsync(
                            "UPDATE [Users] SET [typeAccess] = @locked WHERE [login] = @login",
                            new SQLiteParameter("@locked", "LOCKED"),
                            new SQLiteParameter("@login", login));

                        File.AppendAllText(Logs.file,
                            $"[Вход] Учётная запись {login} заблокирована после 3 неудачных попыток ({_thisDay:dd.MM.yyyy HH:mm}){Environment.NewLine}");

                        MessageBoxUI.Show(
                            "Учётная запись заблокирована из-за множественных неудачных попыток входа.",
                            "Ошибка авторизации", "Error");
                        Close();
                    }
                    else
                    {
                        MessageBoxUI.Show(
                            $"Неверный логин или пароль. Осталось попыток: {_attemptLogin}",
                            "Ошибка авторизации", "Error");
                    }
                    return;
                }

                // 4. Успешный вход — заполняем DataUsers
                DataUsers.Family = row["family"]?.ToString();
                DataUsers.Name = row["name"]?.ToString();
                DataUsers.Father = row["father"]?.ToString();
                DataUsers.Initials = row["initials"]?.ToString();
                DataUsers.Gender = row["gender"]?.ToString();
                DataUsers.Number = row["number"]?.ToString();
                DataUsers.Email = row["email"]?.ToString();
                DataUsers.Depart = row["depart"]?.ToString();
                DataUsers.Position = row["position"]?.ToString();
                DataUsers.Login = row["login"]?.ToString();
                DataUsers.Pass = storedPass; // храним хеш, а не plain
                DataUsers.GroupUser = row["groupUser"]?.ToString();
                DataUsers.Image = row["image"]?.ToString();

                // 5. Загружаем права роли
                await LoadRolePermissionsAsync(DataUsers.GroupUser);

                // 6. Логируем
                File.AppendAllText(Logs.file,
                    $"[Вход] {DataUsers.Initials} ({_thisDay:dd.MM.yyyy HH:mm}){Environment.NewLine}");

                // 7. Проверка слабого пароля
                if (SecurityHelper.IsWeakPassword(password))
                {
                    MessageBoxUI.Show(
                        CertificateSecurity.textError,
                        CertificateSecurity.textHeadError, "Error");
                }

                // 8. Открываем главную форму
                Form mainForm = CreateMainFormByRole(DataUsers.GroupUser);
                mainForm.FormClosed += Form_FormClosed;
                mainForm.Show();
                Hide();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, ex.Source ?? "Ошибка", "Error");
            }
            finally
            {
                ButtonEnterLogin.Enabled = true;
                Cursor = Cursors.Default;
            }
        }

        private async Task LoadRolePermissionsAsync(string role)
        {
            if (string.IsNullOrEmpty(role)) return;

            const string sql = @"
                SELECT * FROM [RightsRoles] 
                WHERE [role] = @role 
                LIMIT 1";

            var table = await DbHelper.ExecuteQueryAsync(sql,
                new SQLiteParameter("@role", role));

            if (table.Rows.Count == 0) return;

            DataRow r = table.Rows[0];

            ConstructorWindow.Calendar = ToBool(r["w_calendar"]);
            ConstructorWindow.AllUsers = ToBool(r["w_users"]);
            ConstructorWindow.AllInventory = ToBool(r["w_inventory"]);

            ConstructorWindow.TypeJob = ToBool(r["f_typeJob"]);
            ConstructorWindow.Cabinets = ToBool(r["f_cabinets"]);
            ConstructorWindow.Request = ToBool(r["f_status"]);
            ConstructorWindow.Executors = ToBool(r["f_executor"]);

            ConstructorWindow.CloseTicket = ToBool(r["mnBtn_closeTicket"]);
            ConstructorWindow.CreateTicket = ToBool(r["mnBtn_createTicket"]);
            ConstructorWindow.CalendarMax = ToBool(r["mnBtn_calendar"]);

            MiniButtonMenuConfig.About = ToBool(r["mnBtnMenu_about"]);
            MiniButtonMenuConfig.Settings = ToBool(r["mnBtnMenu_settings"]);
            MiniButtonMenuConfig.DataUser = ToBool(r["mnBtnMenu_dataUser"]);
            MiniButtonMenuConfig.Logout = ToBool(r["mnBtnMenu_logout"]);

            ConstructorWindow.Users = ToBool(r["btnMenu_users"]);
            ConstructorWindow.Cartridges = ToBool(r["btnMenu_cartridges"]);
            ConstructorWindow.Licenses = ToBool(r["btnMenu_licenses"]);
            ConstructorWindow.Inventory = ToBool(r["btnMenu_inventory"]);
            ConstructorWindow.Passwords = ToBool(r["btnMenu_passwords"]);
            ConstructorWindow.Contacts = ToBool(r["btnMenu_contacts"]);
            ConstructorWindow.Database = ToBool(r["btnMenu_database"]);
            ConstructorWindow.Excel = ToBool(r["btnMenu_excel"]);
            ConstructorWindow.CreateTicketOther = ToBool(r["btnMenu_createTicket"]);

            if (int.TryParse(r["heightWindow"]?.ToString(), out int h))
                ConstructorWindow.sizeH = h;

            DataUsers.GroupName = r["name"]?.ToString();
        }

        private static bool ToBool(object value)
        {
            if (value == null || value == DBNull.Value) return false;
            if (value is bool b) return b;
            return bool.TryParse(value.ToString(), out bool result) && result;
        }

        private Form CreateMainFormByRole(string role)
        {
            switch (role?.ToUpperInvariant())
            {
                case "ADMIN":
                    return new MainAdminForm();
                case "WORKER":
                    return new MainWorkerForm();
                case "USER":
                    return new MainUserForm();
                default:
                    // Fallback на универсальную форму
                    return new MainFormAll();
            }
        }

        #endregion

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _db?.Close();
            _db?.Dispose();
            base.OnFormClosed(e);
        }
    }
}
