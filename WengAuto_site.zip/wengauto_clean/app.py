# app.py — точка входа АИС «WengAuto»
from flask import Flask
from flask_login import LoginManager
from config import Config
from models import db, User
from modules.website import website_bp
from modules.auth import auth_bp
from modules.crm import crm_bp
from modules.warehouse import warehouse_bp
from modules.admin import admin_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)

    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Для доступа необходимо войти в систему'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Регистрация модулей (blueprints)
    app.register_blueprint(website_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(crm_bp)
    app.register_blueprint(warehouse_bp)
    app.register_blueprint(admin_bp)

    with app.app_context():
        db.create_all()

    return app

if __name__ == '__main__':
    app = create_app()
    # Запуск seed при первом старте
    from seed_data import seed
    seed()
    print('=' * 50)
    print('АИС «WengAuto» запущена')
    print('Сайт: http://127.0.0.1:5000')
    print('CRM:  http://127.0.0.1:5000/crm (admin / admin123)')
    print('=' * 50)
    app.run(host='0.0.0.0', port=5000, debug=True)
