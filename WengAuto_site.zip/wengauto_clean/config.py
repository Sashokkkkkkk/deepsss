# config.py — конфигурация АИС «WengAuto»
import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'wengauto-secret-key-2026-gost34'
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    # База рядом с проектом (работает на Windows / macOS / Linux)
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(BASE_DIR, 'wengauto.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # Показатели назначения из ТЗ (п. 4.1.3)
    MAX_INTERNAL_USERS = 30
    MAX_SITE_VISITORS = 1000
    MAX_CATALOG_ITEMS = 5000
    PAGE_RESPONSE_TIME_SEC = 2
    CRM_RESPONSE_TIME_SEC = 3
    SLA_AVAILABILITY = 99.5
