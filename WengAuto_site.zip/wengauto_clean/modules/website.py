# modules/website.py — публичный веб-сайт (п. 4.2.1)
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from models import db, Car, Lead, Client, Promo, ServiceBooking
from datetime import datetime

website_bp = Blueprint('website', __name__)

@website_bp.route('/')
def index():
    cars = Car.query.filter_by(published=True, status='in_stock').limit(6).all()
    promos = Promo.query.filter_by(active=True).limit(3).all()
    return render_template('index.html', cars=cars, promos=promos)

@website_bp.route('/catalog')
def catalog():
    brand = request.args.get('brand', '')
    model = request.args.get('model', '')
    body_type = request.args.get('body_type', '')
    transmission = request.args.get('transmission', '')
    is_new = request.args.get('is_new', '')
    price_min = request.args.get('price_min', type=float)
    price_max = request.args.get('price_max', type=float)
    year_min = request.args.get('year_min', type=int)

    query = Car.query.filter_by(published=True).filter(Car.status.in_(['in_stock', 'reserved']))

    if brand:
        query = query.filter(Car.brand.ilike(f'%{brand}%'))
    if model:
        query = query.filter(Car.model.ilike(f'%{model}%'))
    if body_type:
        query = query.filter(Car.body_type == body_type)
    if transmission:
        query = query.filter(Car.transmission == transmission)
    if is_new == '1':
        query = query.filter(Car.is_new == True)
    elif is_new == '0':
        query = query.filter(Car.is_new == False)
    if price_min is not None:
        query = query.filter(Car.price >= price_min)
    if price_max is not None:
        query = query.filter(Car.price <= price_max)
    if year_min is not None:
        query = query.filter(Car.year >= year_min)

    cars = query.order_by(Car.created_at.desc()).all()
    brands = db.session.query(Car.brand).distinct().all()
    body_types = db.session.query(Car.body_type).distinct().all()
    return render_template('catalog.html', cars=cars, brands=brands, body_types=body_types,
                           filters=request.args)

@website_bp.route('/car/<int:car_id>')
def car_detail(car_id):
    car = Car.query.get_or_404(car_id)
    return render_template('car_detail.html', car=car)

@website_bp.route('/promos')
def promos():
    items = Promo.query.filter_by(active=True).all()
    return render_template('promos.html', promos=items)

@website_bp.route('/trade-in')
def trade_in():
    return render_template('trade_in.html')

@website_bp.route('/credit')
def credit():
    return render_template('credit.html')

@website_bp.route('/service')
def service():
    return render_template('service.html')

@website_bp.route('/about')
def about():
    return render_template('about.html')

@website_bp.route('/contacts')
def contacts():
    return render_template('contacts.html')

@website_bp.route('/api/credit-calculator', methods=['POST'])
def credit_calculator():
    """Онлайн-калькулятор автокредита (п. 4.2.1 п.4)"""
    data = request.get_json() or {}
    price = float(data.get('price', 0))
    down_payment = float(data.get('down_payment', 0))
    term_months = int(data.get('term_months', 36))
    rate = float(data.get('rate', 12.0)) / 100 / 12  # месячная ставка

    loan = price - down_payment
    if loan <= 0 or term_months <= 0:
        return jsonify({'error': 'Некорректные данные'}), 400

    # Аннуитетный платёж
    if rate > 0:
        monthly = loan * (rate * (1 + rate) ** term_months) / ((1 + rate) ** term_months - 1)
    else:
        monthly = loan / term_months

    total = monthly * term_months
    overpay = total - loan

    return jsonify({
        'monthly_payment': round(monthly, 2),
        'total_payment': round(total, 2),
        'overpay': round(overpay, 2),
        'loan_amount': round(loan, 2)
    })

@website_bp.route('/lead', methods=['POST'])
def create_lead():
    """Формы заявок: обратный звонок, тест-драйв, trade-in и т.д."""
    lead_type = request.form.get('type', 'callback')
    name = request.form.get('name', '').strip()
    phone = request.form.get('phone', '').strip()
    email = request.form.get('email', '').strip()
    message = request.form.get('message', '')
    car_id = request.form.get('car_id', type=int)

    if not name or not phone:
        flash('Укажите имя и телефон', 'danger')
        return redirect(request.referrer or url_for('website.index'))

    client = Client.query.filter_by(phone=phone).first()
    if not client:
        client = Client(full_name=name, phone=phone, email=email or None, source='site')
        db.session.add(client)
        db.session.flush()

    lead = Lead(
        client_id=client.id,
        type=lead_type,
        message=message,
        car_id=car_id,
        status='new'
    )
    db.session.add(lead)
    db.session.commit()

    flash('Заявка успешно отправлена! Менеджер свяжется с вами в ближайшее время.', 'success')
    return redirect(request.referrer or url_for('website.index'))

@website_bp.route('/service/book', methods=['POST'])
def book_service():
    """Онлайн-запись на сервис (п. 4.2.4)"""
    name = request.form.get('name', '').strip()
    phone = request.form.get('phone', '').strip()
    car_info = request.form.get('car_info', '')
    service_type = request.form.get('service_type', '')
    preferred_date = request.form.get('preferred_date')
    notes = request.form.get('notes', '')

    if not name or not phone:
        flash('Укажите имя и телефон', 'danger')
        return redirect(url_for('website.service'))

    booking = ServiceBooking(
        client_name=name,
        phone=phone,
        car_info=car_info,
        service_type=service_type,
        preferred_date=datetime.fromisoformat(preferred_date) if preferred_date else None,
        notes=notes
    )
    db.session.add(booking)
    db.session.commit()
    flash('Запись на сервис принята! Мы подтвердим время звонком.', 'success')
    return redirect(url_for('website.service'))
