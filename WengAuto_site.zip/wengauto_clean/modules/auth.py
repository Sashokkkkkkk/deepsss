# modules/auth.py — аутентификация и авторизация (п. 4.1.8)
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from models import db, User, AuditLog
from functools import wraps

auth_bp = Blueprint('auth', __name__)

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                return redirect(url_for('auth.login'))
            if current_user.role not in roles and current_user.role != 'admin':
                flash('Недостаточно прав доступа', 'danger')
                return redirect(url_for('website.index'))
            return f(*args, **kwargs)
        return wrapped
    return decorator

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('crm.dashboard'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password) and user.is_active:
            login_user(user)
            log = AuditLog(user_id=user.id, action='login', details=f'Вход пользователя {username}')
            db.session.add(log)
            db.session.commit()
            flash(f'Добро пожаловать, {user.full_name or user.username}!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('crm.dashboard'))
        flash('Неверный логин или пароль', 'danger')
    return render_template('login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    log = AuditLog(user_id=current_user.id, action='logout', details='Выход из системы')
    db.session.add(log)
    db.session.commit()
    logout_user()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('website.index'))
