АИС «WengAuto» — прототип по ГОСТ 34.602-89
=============================================

1. Откройте папку wengauto в PyCharm (File → Open).
2. Создайте venv: Settings → Python Interpreter → Add → Virtualenv.
3. В Terminal PyCharm:
   pip install -r requirements.txt
4. Запустите app.py (зелёная кнопка Run).
5. Откройте в браузере: http://127.0.0.1:5000

Логины:
  admin / admin123
  manager / manager123
  warehouse / warehouse123

При первом запуске создастся файл wengauto.db и загрузятся демо-данные.
