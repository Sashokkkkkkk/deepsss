import os, secrets
class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    _db = os.environ.get('SQLITE_PATH') or os.path.join(BASE_DIR, 'wengauto.db')
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or ('sqlite:///' + _db)
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = 3600
    RATELIMIT_STORAGE_URI = 'memory://'
    RATELIMIT_DEFAULT = '200 per hour;60 per minute'
    BLOCKED_UA_SUBSTRINGS = ['gptbot','chatgpt','ccbot','claudebot','scrapy','python-requests','curl/','selenium']
    ALLOWED_BOT_UA = ['googlebot','bingbot','yandexbot']
    MAX_NAME_LEN = 150
    MAX_MESSAGE_LEN = 2000
