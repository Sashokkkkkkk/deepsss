ФОТО БЕЗ ИНТЕРНЕТА
==================
1. Скопируйте папку static\img целиком в D:\wengauto_clean\static\img\
2. Замените seed_data.py, models.py, static\css\style.css
3. modules\warehouse.py и templates\index.html, catalog.html, car_detail.html
4. УДАЛИТЕ wengauto.db
5. Запустите app.py снова
