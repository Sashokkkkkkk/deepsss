# Дополнительный модуль: Статистика и отчёты

## Что делает модуль

Форма **StatisticsForm** показывает в реальном времени:

| Блок              | Что отображается                                      |
|-------------------|-------------------------------------------------------|
| **Заявки**        | Всего / Открытые / Закрытые / За сегодня + таблица по статусам |
| **Пользователи**  | Всего + разбивка по группам + топ-5 отделов           |
| **Инвентарь**     | Количество позиций                                    |
| **Картриджи**     | Всего + те, что «требуют внимания» (заполнен date8)   |

Дополнительно:
- Кнопка **«Обновить»** — перезагружает все данные из БД
- Кнопка **«В Excel»** — экспортирует полный отчёт в `.xlsx` (использует уже имеющийся в проекте Microsoft.Office.Interop.Excel)

Стиль формы соответствует остальным формам SupportDesk (безрамочное окно, тёмный заголовок, возможность перетаскивать).

---

## Как подключить

### 1. Добавить файлы в проект

Скопируйте оба файла в папку `forms` вашего проекта:

```
SupportDesk/forms/StatisticsForm.cs
SupportDesk/forms/StatisticsForm.Designer.cs
```

В Visual Studio:
1. ПКМ по папке `forms` → **Add → Existing Item…**
2. Выберите оба файла.

Либо вручную добавьте в `.csproj` (если не используете авто-включение):

```xml
<Compile Include="forms\StatisticsForm.cs">
  <SubType>Form</SubType>
</Compile>
<Compile Include="forms\StatisticsForm.Designer.cs">
  <DependentUpon>StatisticsForm.cs</DependentUpon>
</Compile>
```

### 2. Открыть форму из главного окна

В `MainAdminForm.cs` (или `MainWorkerForm.cs`) добавьте кнопку / пункт меню и обработчик:

```csharp
private void btnStatistics_Click(object sender, EventArgs e)
{
    using (var form = new StatisticsForm())
    {
        form.ShowDialog();
    }
}
```

Или без `using` (если хотите оставить форму открытой):

```csharp
private void btnStatistics_Click(object sender, EventArgs e)
{
    StatisticsForm form = new StatisticsForm();
    form.Show();
}
```

### 3. (Опционально) Добавить кнопку на форму

В дизайнере `MainAdminForm` создайте кнопку (например, `btnStatistics`) с текстом «Статистика» и привяжите событие `Click` к методу выше.

---

## Требования

- Уже используется в проекте:
  - `System.Data.SQLite`
  - `Microsoft.Office.Interop.Excel`
  - классы `Database`, `Table_requests`, `Table_users`, `Table_inventory`, `Table_cartrigde`, `MessageBoxUI`, `DataUsers`
- .NET Framework 4.8 (как у основного проекта)

---

## Возможные доработки

- Добавить фильтр по дате (заявки за период)
- Графики (можно через `System.Windows.Forms.DataVisualization.Charting`)
- Автообновление по таймеру
- Статистика по исполнителям (кто сколько заявок закрыл)

Если нужны другие модули (база знаний, резервное копирование, быстрый поиск и т.д.) — напишите.
