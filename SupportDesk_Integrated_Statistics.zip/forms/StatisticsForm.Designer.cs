namespace SupportDesk.forms
{
    partial class StatisticsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.panelHeader = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.labelLastUpdate = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.groupBoxRequests = new System.Windows.Forms.GroupBox();
            this.labelTodayRequests = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelClosedRequests = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelOpenRequests = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelTotalRequests = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewStatus = new System.Windows.Forms.DataGridView();
            this.ColumnStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBoxUsers = new System.Windows.Forms.GroupBox();
            this.dataGridViewDepart = new System.Windows.Forms.DataGridView();
            this.ColumnDepart = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDepartCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewGroups = new System.Windows.Forms.DataGridView();
            this.ColumnGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnGroupCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelTotalUsers = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBoxInventory = new System.Windows.Forms.GroupBox();
            this.labelCartridgesAttention = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labelTotalCartridges = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelTotalInventory = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panelHeader.SuspendLayout();
            this.groupBoxRequests.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStatus)).BeginInit();
            this.groupBoxUsers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDepart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGroups)).BeginInit();
            this.groupBoxInventory.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.panelHeader.Controls.Add(this.labelTitle);
            this.panelHeader.Controls.Add(this.btnClose);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(920, 42);
            this.panelHeader.TabIndex = 0;
            this.panelHeader.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelHeader_MouseDown);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.labelTitle.ForeColor = System.Drawing.Color.White;
            this.labelTitle.Location = new System.Drawing.Point(12, 10);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(280, 21);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "📊 Статистика и отчёты SupportDesk";
            this.labelTitle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelHeader_MouseDown);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(43)))));
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(872, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(40, 32);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "✕";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // labelLastUpdate
            // 
            this.labelLastUpdate.AutoSize = true;
            this.labelLastUpdate.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.labelLastUpdate.ForeColor = System.Drawing.Color.Gray;
            this.labelLastUpdate.Location = new System.Drawing.Point(12, 55);
            this.labelLastUpdate.Name = "labelLastUpdate";
            this.labelLastUpdate.Size = new System.Drawing.Size(120, 15);
            this.labelLastUpdate.TabIndex = 1;
            this.labelLastUpdate.Text = "Обновлено: —";
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.btnRefresh.FlatAppearance.BorderSize = 0;
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnRefresh.ForeColor = System.Drawing.Color.White;
            this.btnRefresh.Location = new System.Drawing.Point(680, 48);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(110, 32);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Обновить";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnExportExcel.FlatAppearance.BorderSize = 0;
            this.btnExportExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportExcel.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnExportExcel.ForeColor = System.Drawing.Color.White;
            this.btnExportExcel.Location = new System.Drawing.Point(796, 48);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(110, 32);
            this.btnExportExcel.TabIndex = 3;
            this.btnExportExcel.Text = "В Excel";
            this.btnExportExcel.UseVisualStyleBackColor = false;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // groupBoxRequests
            // 
            this.groupBoxRequests.Controls.Add(this.labelTodayRequests);
            this.groupBoxRequests.Controls.Add(this.label4);
            this.groupBoxRequests.Controls.Add(this.labelClosedRequests);
            this.groupBoxRequests.Controls.Add(this.label3);
            this.groupBoxRequests.Controls.Add(this.labelOpenRequests);
            this.groupBoxRequests.Controls.Add(this.label2);
            this.groupBoxRequests.Controls.Add(this.labelTotalRequests);
            this.groupBoxRequests.Controls.Add(this.label1);
            this.groupBoxRequests.Controls.Add(this.dataGridViewStatus);
            this.groupBoxRequests.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.groupBoxRequests.Location = new System.Drawing.Point(12, 90);
            this.groupBoxRequests.Name = "groupBoxRequests";
            this.groupBoxRequests.Size = new System.Drawing.Size(440, 280);
            this.groupBoxRequests.TabIndex = 4;
            this.groupBoxRequests.TabStop = false;
            this.groupBoxRequests.Text = "Заявки";
            // 
            // labelTodayRequests
            // 
            this.labelTodayRequests.AutoSize = true;
            this.labelTodayRequests.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.labelTodayRequests.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.labelTodayRequests.Location = new System.Drawing.Point(320, 70);
            this.labelTodayRequests.Name = "labelTodayRequests";
            this.labelTodayRequests.Size = new System.Drawing.Size(23, 25);
            this.labelTodayRequests.TabIndex = 8;
            this.labelTodayRequests.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label4.Location = new System.Drawing.Point(320, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "За сегодня";
            // 
            // labelClosedRequests
            // 
            this.labelClosedRequests.AutoSize = true;
            this.labelClosedRequests.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.labelClosedRequests.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.labelClosedRequests.Location = new System.Drawing.Point(220, 70);
            this.labelClosedRequests.Name = "labelClosedRequests";
            this.labelClosedRequests.Size = new System.Drawing.Size(23, 25);
            this.labelClosedRequests.TabIndex = 6;
            this.labelClosedRequests.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label3.Location = new System.Drawing.Point(220, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Закрытые";
            // 
            // labelOpenRequests
            // 
            this.labelOpenRequests.AutoSize = true;
            this.labelOpenRequests.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.labelOpenRequests.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(126)))), ((int)(((byte)(34)))));
            this.labelOpenRequests.Location = new System.Drawing.Point(120, 70);
            this.labelOpenRequests.Name = "labelOpenRequests";
            this.labelOpenRequests.Size = new System.Drawing.Size(23, 25);
            this.labelOpenRequests.TabIndex = 4;
            this.labelOpenRequests.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label2.Location = new System.Drawing.Point(120, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Открытые";
            // 
            // labelTotalRequests
            // 
            this.labelTotalRequests.AutoSize = true;
            this.labelTotalRequests.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.labelTotalRequests.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.labelTotalRequests.Location = new System.Drawing.Point(20, 65);
            this.labelTotalRequests.Name = "labelTotalRequests";
            this.labelTotalRequests.Size = new System.Drawing.Size(26, 30);
            this.labelTotalRequests.TabIndex = 2;
            this.labelTotalRequests.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label1.Location = new System.Drawing.Point(20, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Всего";
            // 
            // dataGridViewStatus
            // 
            this.dataGridViewStatus.AllowUserToAddRows = false;
            this.dataGridViewStatus.AllowUserToDeleteRows = false;
            this.dataGridViewStatus.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStatus.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnStatus,
            this.ColumnCount});
            this.dataGridViewStatus.Location = new System.Drawing.Point(15, 110);
            this.dataGridViewStatus.Name = "dataGridViewStatus";
            this.dataGridViewStatus.ReadOnly = true;
            this.dataGridViewStatus.RowHeadersVisible = false;
            this.dataGridViewStatus.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewStatus.Size = new System.Drawing.Size(410, 155);
            this.dataGridViewStatus.TabIndex = 0;
            // 
            // ColumnStatus
            // 
            this.ColumnStatus.HeaderText = "Статус";
            this.ColumnStatus.Name = "ColumnStatus";
            this.ColumnStatus.ReadOnly = true;
            this.ColumnStatus.Width = 280;
            // 
            // ColumnCount
            // 
            this.ColumnCount.HeaderText = "Кол-во";
            this.ColumnCount.Name = "ColumnCount";
            this.ColumnCount.ReadOnly = true;
            this.ColumnCount.Width = 100;
            // 
            // groupBoxUsers
            // 
            this.groupBoxUsers.Controls.Add(this.dataGridViewDepart);
            this.groupBoxUsers.Controls.Add(this.dataGridViewGroups);
            this.groupBoxUsers.Controls.Add(this.labelTotalUsers);
            this.groupBoxUsers.Controls.Add(this.label5);
            this.groupBoxUsers.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.groupBoxUsers.Location = new System.Drawing.Point(468, 90);
            this.groupBoxUsers.Name = "groupBoxUsers";
            this.groupBoxUsers.Size = new System.Drawing.Size(440, 280);
            this.groupBoxUsers.TabIndex = 5;
            this.groupBoxUsers.TabStop = false;
            this.groupBoxUsers.Text = "Пользователи";
            // 
            // dataGridViewDepart
            // 
            this.dataGridViewDepart.AllowUserToAddRows = false;
            this.dataGridViewDepart.AllowUserToDeleteRows = false;
            this.dataGridViewDepart.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewDepart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDepart.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnDepart,
            this.ColumnDepartCount});
            this.dataGridViewDepart.Location = new System.Drawing.Point(15, 180);
            this.dataGridViewDepart.Name = "dataGridViewDepart";
            this.dataGridViewDepart.ReadOnly = true;
            this.dataGridViewDepart.RowHeadersVisible = false;
            this.dataGridViewDepart.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDepart.Size = new System.Drawing.Size(410, 85);
            this.dataGridViewDepart.TabIndex = 3;
            // 
            // ColumnDepart
            // 
            this.ColumnDepart.HeaderText = "Отдел (топ-5)";
            this.ColumnDepart.Name = "ColumnDepart";
            this.ColumnDepart.ReadOnly = true;
            this.ColumnDepart.Width = 280;
            // 
            // ColumnDepartCount
            // 
            this.ColumnDepartCount.HeaderText = "Кол-во";
            this.ColumnDepartCount.Name = "ColumnDepartCount";
            this.ColumnDepartCount.ReadOnly = true;
            this.ColumnDepartCount.Width = 100;
            // 
            // dataGridViewGroups
            // 
            this.dataGridViewGroups.AllowUserToAddRows = false;
            this.dataGridViewGroups.AllowUserToDeleteRows = false;
            this.dataGridViewGroups.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewGroups.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGroups.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnGroup,
            this.ColumnGroupCount});
            this.dataGridViewGroups.Location = new System.Drawing.Point(15, 70);
            this.dataGridViewGroups.Name = "dataGridViewGroups";
            this.dataGridViewGroups.ReadOnly = true;
            this.dataGridViewGroups.RowHeadersVisible = false;
            this.dataGridViewGroups.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewGroups.Size = new System.Drawing.Size(410, 100);
            this.dataGridViewGroups.TabIndex = 2;
            // 
            // ColumnGroup
            // 
            this.ColumnGroup.HeaderText = "Группа";
            this.ColumnGroup.Name = "ColumnGroup";
            this.ColumnGroup.ReadOnly = true;
            this.ColumnGroup.Width = 280;
            // 
            // ColumnGroupCount
            // 
            this.ColumnGroupCount.HeaderText = "Кол-во";
            this.ColumnGroupCount.Name = "ColumnGroupCount";
            this.ColumnGroupCount.ReadOnly = true;
            this.ColumnGroupCount.Width = 100;
            // 
            // labelTotalUsers
            // 
            this.labelTotalUsers.AutoSize = true;
            this.labelTotalUsers.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.labelTotalUsers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.labelTotalUsers.Location = new System.Drawing.Point(100, 30);
            this.labelTotalUsers.Name = "labelTotalUsers";
            this.labelTotalUsers.Size = new System.Drawing.Size(26, 30);
            this.labelTotalUsers.TabIndex = 1;
            this.labelTotalUsers.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label5.Location = new System.Drawing.Point(15, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "Всего юзеров:";
            // 
            // groupBoxInventory
            // 
            this.groupBoxInventory.Controls.Add(this.labelCartridgesAttention);
            this.groupBoxInventory.Controls.Add(this.label8);
            this.groupBoxInventory.Controls.Add(this.labelTotalCartridges);
            this.groupBoxInventory.Controls.Add(this.label7);
            this.groupBoxInventory.Controls.Add(this.labelTotalInventory);
            this.groupBoxInventory.Controls.Add(this.label6);
            this.groupBoxInventory.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.groupBoxInventory.Location = new System.Drawing.Point(12, 385);
            this.groupBoxInventory.Name = "groupBoxInventory";
            this.groupBoxInventory.Size = new System.Drawing.Size(896, 100);
            this.groupBoxInventory.TabIndex = 6;
            this.groupBoxInventory.TabStop = false;
            this.groupBoxInventory.Text = "Инвентарь и картриджи";
            // 
            // labelCartridgesAttention
            // 
            this.labelCartridgesAttention.AutoSize = true;
            this.labelCartridgesAttention.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.labelCartridgesAttention.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.labelCartridgesAttention.Location = new System.Drawing.Point(620, 50);
            this.labelCartridgesAttention.Name = "labelCartridgesAttention";
            this.labelCartridgesAttention.Size = new System.Drawing.Size(26, 30);
            this.labelCartridgesAttention.TabIndex = 5;
            this.labelCartridgesAttention.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label8.Location = new System.Drawing.Point(620, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(180, 15);
            this.label8.TabIndex = 4;
            this.label8.Text = "Картриджи (требуют внимания)";
            // 
            // labelTotalCartridges
            // 
            this.labelTotalCartridges.AutoSize = true;
            this.labelTotalCartridges.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.labelTotalCartridges.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(89)))), ((int)(((byte)(182)))));
            this.labelTotalCartridges.Location = new System.Drawing.Point(320, 50);
            this.labelTotalCartridges.Name = "labelTotalCartridges";
            this.labelTotalCartridges.Size = new System.Drawing.Size(26, 30);
            this.labelTotalCartridges.TabIndex = 3;
            this.labelTotalCartridges.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label7.Location = new System.Drawing.Point(320, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 15);
            this.label7.TabIndex = 2;
            this.label7.Text = "Всего картриджей";
            // 
            // labelTotalInventory
            // 
            this.labelTotalInventory.AutoSize = true;
            this.labelTotalInventory.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.labelTotalInventory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.labelTotalInventory.Location = new System.Drawing.Point(20, 50);
            this.labelTotalInventory.Name = "labelTotalInventory";
            this.labelTotalInventory.Size = new System.Drawing.Size(26, 30);
            this.labelTotalInventory.TabIndex = 1;
            this.labelTotalInventory.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label6.Location = new System.Drawing.Point(20, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "Всего позиций инвентаря";
            // 
            // StatisticsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(246)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(920, 505);
            this.Controls.Add(this.groupBoxInventory);
            this.Controls.Add(this.groupBoxUsers);
            this.Controls.Add(this.groupBoxRequests);
            this.Controls.Add(this.btnExportExcel);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.labelLastUpdate);
            this.Controls.Add(this.panelHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StatisticsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Статистика SupportDesk";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.StatisticsForm_FormClosing);
            this.Load += new System.EventHandler(this.StatisticsForm_Load);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.groupBoxRequests.ResumeLayout(false);
            this.groupBoxRequests.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStatus)).EndInit();
            this.groupBoxUsers.ResumeLayout(false);
            this.groupBoxUsers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDepart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGroups)).EndInit();
            this.groupBoxInventory.ResumeLayout(false);
            this.groupBoxInventory.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label labelLastUpdate;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.GroupBox groupBoxRequests;
        private System.Windows.Forms.DataGridView dataGridViewStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelTotalRequests;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelOpenRequests;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelClosedRequests;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelTodayRequests;
        private System.Windows.Forms.GroupBox groupBoxUsers;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelTotalUsers;
        private System.Windows.Forms.DataGridView dataGridViewGroups;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnGroupCount;
        private System.Windows.Forms.DataGridView dataGridViewDepart;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDepart;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDepartCount;
        private System.Windows.Forms.GroupBox groupBoxInventory;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelTotalInventory;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelTotalCartridges;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelCartridgesAttention;
    }
}
