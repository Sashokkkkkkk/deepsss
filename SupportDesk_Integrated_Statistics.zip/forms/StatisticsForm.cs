using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace SupportDesk.forms
{
    /// <summary>
    /// Дополнительный модуль: Статистика и отчёты SupportDesk
    /// Показывает сводку по заявкам, пользователям, инвентарю и картриджам.
    /// </summary>
    public partial class StatisticsForm : Form
    {
        #region Настройка формы (перетаскивание)
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        #endregion

        private SQLiteConnection DB;

        public StatisticsForm()
        {
            InitializeComponent();
        }

        private async void StatisticsForm_Load(object sender, EventArgs e)
        {
            try
            {
                DB = new SQLiteConnection(Database.connectionString);
                await DB.OpenAsync();
                await LoadAllStatisticsAsync();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, "Ошибка загрузки статистики", "Error");
            }
        }

        private async Task LoadAllStatisticsAsync()
        {
            await LoadRequestsStatsAsync();
            await LoadUsersStatsAsync();
            await LoadInventoryStatsAsync();
            await LoadCartridgesStatsAsync();
            labelLastUpdate.Text = "Обновлено: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
        }

        #region Заявки
        private async Task LoadRequestsStatsAsync()
        {
            try
            {
                // Всего заявок
                using (var cmd = new SQLiteCommand($"SELECT COUNT(*) FROM [{Table_requests.main}]", DB))
                {
                    labelTotalRequests.Text = (await cmd.ExecuteScalarAsync())?.ToString() ?? "0";
                }

                // По статусам
                dataGridViewStatus.Rows.Clear();
                using (var cmd = new SQLiteCommand(
                    $"SELECT {Table_requests.status}, COUNT(*) as cnt FROM [{Table_requests.main}] GROUP BY {Table_requests.status} ORDER BY cnt DESC", DB))
                using (var reader = (SQLiteDataReader)await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        string status = reader[Table_requests.status]?.ToString() ?? "—";
                        int count = Convert.ToInt32(reader["cnt"]);
                        dataGridViewStatus.Rows.Add(status, count);
                    }
                }

                // Открытые / закрытые (примерная логика)
                using (var cmd = new SQLiteCommand(
                    $"SELECT COUNT(*) FROM [{Table_requests.main}] WHERE {Table_requests.status} IN ('Новая','В работе','Ожидание')", DB))
                {
                    labelOpenRequests.Text = (await cmd.ExecuteScalarAsync())?.ToString() ?? "0";
                }

                using (var cmd = new SQLiteCommand(
                    $"SELECT COUNT(*) FROM [{Table_requests.main}] WHERE {Table_requests.status} IN ('Выполнена','Закрыта','Отменена')", DB))
                {
                    labelClosedRequests.Text = (await cmd.ExecuteScalarAsync())?.ToString() ?? "0";
                }

                // Заявки за сегодня
                string today = DateTime.Now.ToString("dd.MM.yyyy");
                using (var cmd = new SQLiteCommand(
                    $"SELECT COUNT(*) FROM [{Table_requests.main}] WHERE {Table_requests.date} = @d", DB))
                {
                    cmd.Parameters.AddWithValue("@d", today);
                    labelTodayRequests.Text = (await cmd.ExecuteScalarAsync())?.ToString() ?? "0";
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show("Заявки: " + ex.Message, "Статистика", "Error");
            }
        }
        #endregion

        #region Пользователи
        private async Task LoadUsersStatsAsync()
        {
            try
            {
                using (var cmd = new SQLiteCommand($"SELECT COUNT(*) FROM [{Table_users.main}]", DB))
                {
                    labelTotalUsers.Text = (await cmd.ExecuteScalarAsync())?.ToString() ?? "0";
                }

                dataGridViewGroups.Rows.Clear();
                using (var cmd = new SQLiteCommand(
                    $"SELECT {Table_users.groupUser}, COUNT(*) as cnt FROM [{Table_users.main}] GROUP BY {Table_users.groupUser} ORDER BY cnt DESC", DB))
                using (var reader = (SQLiteDataReader)await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        string group = reader[Table_users.groupUser]?.ToString() ?? "—";
                        int count = Convert.ToInt32(reader["cnt"]);
                        dataGridViewGroups.Rows.Add(group, count);
                    }
                }

                // По отделам (топ-5)
                dataGridViewDepart.Rows.Clear();
                using (var cmd = new SQLiteCommand(
                    $"SELECT {Table_users.depart}, COUNT(*) as cnt FROM [{Table_users.main}] GROUP BY {Table_users.depart} ORDER BY cnt DESC LIMIT 5", DB))
                using (var reader = (SQLiteDataReader)await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        string dep = reader[Table_users.depart]?.ToString() ?? "—";
                        int count = Convert.ToInt32(reader["cnt"]);
                        dataGridViewDepart.Rows.Add(dep, count);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show("Пользователи: " + ex.Message, "Статистика", "Error");
            }
        }
        #endregion

        #region Инвентарь
        private async Task LoadInventoryStatsAsync()
        {
            try
            {
                using (var cmd = new SQLiteCommand($"SELECT COUNT(*) FROM [{Table_inventory.main}]", DB))
                {
                    labelTotalInventory.Text = (await cmd.ExecuteScalarAsync())?.ToString() ?? "0";
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show("Инвентарь: " + ex.Message, "Статистика", "Error");
            }
        }
        #endregion

        #region Картриджи
        private async Task LoadCartridgesStatsAsync()
        {
            try
            {
                using (var cmd = new SQLiteCommand($"SELECT COUNT(*) FROM [{Table_cartrigde.main}]", DB))
                {
                    labelTotalCartridges.Text = (await cmd.ExecuteScalarAsync())?.ToString() ?? "0";
                }

                // Картриджи, у которых заполнены почти все даты замены (условно «нужно внимание»)
                // Простая эвристика: если date8 заполнена — давно в работе
                using (var cmd = new SQLiteCommand(
                    $"SELECT COUNT(*) FROM [{Table_cartrigde.main}] WHERE {Table_cartrigde.date8} IS NOT NULL AND {Table_cartrigde.date8} != ''", DB))
                {
                    labelCartridgesAttention.Text = (await cmd.ExecuteScalarAsync())?.ToString() ?? "0";
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show("Картриджи: " + ex.Message, "Статистика", "Error");
            }
        }
        #endregion

        private async void btnRefresh_Click(object sender, EventArgs e)
        {
            btnRefresh.Enabled = false;
            btnRefresh.Text = "Обновление...";
            try
            {
                await LoadAllStatisticsAsync();
            }
            finally
            {
                btnRefresh.Enabled = true;
                btnRefresh.Text = "Обновить";
            }
        }

        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            try
            {
                Excel.Application excelApp = new Excel.Application();
                excelApp.Visible = false;
                Excel.Workbook workbook = excelApp.Workbooks.Add();
                Excel.Worksheet sheet = (Excel.Worksheet)workbook.Sheets[1];
                sheet.Name = "Статистика SupportDesk";

                int row = 1;
                sheet.Cells[row, 1] = "Отчёт статистики SupportDesk";
                sheet.Cells[row, 1].Font.Bold = true;
                sheet.Cells[row, 1].Font.Size = 14;
                row += 2;

                sheet.Cells[row, 1] = "Дата формирования:";
                sheet.Cells[row, 2] = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
                row += 2;

                // Заявки
                sheet.Cells[row, 1] = "ЗАЯВКИ";
                sheet.Cells[row, 1].Font.Bold = true;
                row++;
                sheet.Cells[row, 1] = "Всего заявок:";
                sheet.Cells[row, 2] = labelTotalRequests.Text;
                row++;
                sheet.Cells[row, 1] = "Открытые:";
                sheet.Cells[row, 2] = labelOpenRequests.Text;
                row++;
                sheet.Cells[row, 1] = "Закрытые:";
                sheet.Cells[row, 2] = labelClosedRequests.Text;
                row++;
                sheet.Cells[row, 1] = "За сегодня:";
                sheet.Cells[row, 2] = labelTodayRequests.Text;
                row += 2;

                sheet.Cells[row, 1] = "По статусам:";
                sheet.Cells[row, 1].Font.Bold = true;
                row++;
                sheet.Cells[row, 1] = "Статус";
                sheet.Cells[row, 2] = "Количество";
                sheet.Cells[row, 1].Font.Bold = true;
                sheet.Cells[row, 2].Font.Bold = true;
                row++;
                foreach (DataGridViewRow dgRow in dataGridViewStatus.Rows)
                {
                    if (dgRow.Cells[0].Value != null)
                    {
                        sheet.Cells[row, 1] = dgRow.Cells[0].Value.ToString();
                        sheet.Cells[row, 2] = dgRow.Cells[1].Value.ToString();
                        row++;
                    }
                }
                row += 2;

                // Пользователи
                sheet.Cells[row, 1] = "ПОЛЬЗОВАТЕЛИ";
                sheet.Cells[row, 1].Font.Bold = true;
                row++;
                sheet.Cells[row, 1] = "Всего пользователей:";
                sheet.Cells[row, 2] = labelTotalUsers.Text;
                row += 2;

                sheet.Cells[row, 1] = "По группам:";
                sheet.Cells[row, 1].Font.Bold = true;
                row++;
                sheet.Cells[row, 1] = "Группа";
                sheet.Cells[row, 2] = "Количество";
                sheet.Cells[row, 1].Font.Bold = true;
                sheet.Cells[row, 2].Font.Bold = true;
                row++;
                foreach (DataGridViewRow dgRow in dataGridViewGroups.Rows)
                {
                    if (dgRow.Cells[0].Value != null)
                    {
                        sheet.Cells[row, 1] = dgRow.Cells[0].Value.ToString();
                        sheet.Cells[row, 2] = dgRow.Cells[1].Value.ToString();
                        row++;
                    }
                }
                row += 2;

                // Инвентарь и картриджи
                sheet.Cells[row, 1] = "ИНВЕНТАРЬ И КАРТРИДЖИ";
                sheet.Cells[row, 1].Font.Bold = true;
                row++;
                sheet.Cells[row, 1] = "Всего позиций инвентаря:";
                sheet.Cells[row, 2] = labelTotalInventory.Text;
                row++;
                sheet.Cells[row, 1] = "Всего картриджей:";
                sheet.Cells[row, 2] = labelTotalCartridges.Text;
                row++;
                sheet.Cells[row, 1] = "Картриджи, требующие внимания:";
                sheet.Cells[row, 2] = labelCartridgesAttention.Text;

                sheet.Columns.AutoFit();

                SaveFileDialog sfd = new SaveFileDialog
                {
                    Filter = "Excel файлы (*.xlsx)|*.xlsx",
                    FileName = $"SupportDesk_Statistics_{DateTime.Now:yyyyMMdd_HHmm}.xlsx"
                };

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    workbook.SaveAs(sfd.FileName);
                    MessageBoxUI.Show("Отчёт успешно сохранён:\n" + sfd.FileName, "Экспорт", "Accept");
                }

                workbook.Close(false);
                excelApp.Quit();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show("Ошибка экспорта: " + ex.Message, "Экспорт в Excel", "Error");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void panelHeader_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void StatisticsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                DB?.Close();
                DB?.Dispose();
            }
            catch { /* ignore */ }
        }
    }
}
