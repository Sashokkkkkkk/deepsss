SupportDesk + модуль «Статистика»
================================

Что изменено:
1. Добавлены forms/StatisticsForm.cs и StatisticsForm.Designer.cs
2. В SupportDesk.csproj добавлены Compile-записи для новой формы
3. В MainAdminForm (левая панель) добавлена кнопка «Статистика» (Y=285)
4. По нажатию открывается окно статистики с отчётами и экспортом в Excel

Как открыть проект:
- Откройте SupportDesk.sln в Visual Studio
- Восстановите NuGet-пакеты (packages были исключены из архива из-за размера —
  они есть в оригинальном SupportDesk.7z в папке packages)
- Либо: скопируйте папку packages из оригинального архива рядом с .sln
- Соберите (Release или Debug)

Кнопка «Статистика» появляется в боковой панели главного окна администратора.

Если packages нет:
1. Распакуйте оригинальный SupportDesk.7z
2. Скопируйте папку packages в SupportDesk/
3. Откройте .sln и соберите

Модуль использует уже имеющиеся:
- System.Data.SQLite
- Microsoft.Office.Interop.Excel
- Table_*, Database, MessageBoxUI
